import java.io.*;
import java.nio.file.*;
import java.util.*;


public class Second {

}
