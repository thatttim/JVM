//
// SmartPhone.java
// Property of Framework LLC
// Author - Tim Sarkisiani
//

public class SmartPhone extends Phone {
    @Override
    public void makeCall() {
        System.out.println("Making a call from SmartPhone");
    }
}