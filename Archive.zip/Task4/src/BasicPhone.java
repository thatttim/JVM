//
// BasicPhone.java
// Property of Framework LLC
// Author - Tim Sarkisiani
//

public class BasicPhone extends SmartPhone {
    @Override
    public void makeCall() {
        System.out.println("Making a call from BasicPhone");
    }
}