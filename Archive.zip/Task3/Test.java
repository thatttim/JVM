// Vehicle Class
class Vehicle {
    private String make;
    private String model;

    public Vehicle(String make, String model) {
        this.make = make;
        this.model = model;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}

// Car Class
class Car extends Vehicle {
    private int year;
    private String type; // sedan, SUV, hatchback
    private int horsepower;

    public Car(String make, String model, int year, String type, int horsepower) {
        super(make, model);
        this.year = year;
        this.type = type;
        this.horsepower = horsepower;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getHorsepower() {
        return horsepower;
    }

    public void setHorsepower(int horsepower) {
        this.horsepower = horsepower;
    }
}

// Person Class
class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}

// Student Class
class Student extends Person {
    private String university;
    private String course;

    public Student(String name, int age, String university, String course) {
        super(name, age);
        this.university = university;
        this.course = course;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}

// Employee Class
class Employee extends Person {
    private double salary;

    public Employee(String name, int age, double salary) {
        super(name, age);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getSalaryCategory() {
        if (salary > 6000) {
            return "High salary";
        } else if (salary < 2000) {
            return "Low salary";
        } else {
            return "Average salary";
        }
    }
}

// Main Class
public class Main {
    public static void main(String[] args) {
        // Create Car Object
        Car car = new Car("Toyota", "Corolla", 2020, "Sedan", 132);
        System.out.println("Car make: " + car.getMake());
        System.out.println("Car model: " + car.getModel());
        System.out.println("Car type: " + car.getType());

        // Create Student Object
        Student student = new Student("Alice", 20, "Tbilisi State University", "Computer Science");
        System.out.println("Student name: " + student.getName());
        System.out.println("University: " + student.getUniversity());

        // Create Employee Object
        Employee employee = new Employee("Bob", 30, 2500);
        System.out.println("Employee name: " + employee.getName());
        System.out.println("Salary category: " + employee.getSalaryCategory());
    }
}
