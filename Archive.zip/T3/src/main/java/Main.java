import org.apache.log4j.Logger;
import java.util.Scanner;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class);

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // გენერაცია
        int[] fibonacci = generateFibonacciSeries(100);

        // ამობეჭდვა
        logger.info("ფიბონაჩის რიცხვები:");
        for (int number : fibonacci) {
            logger.info(number + " ");
        }

        // ვკითხოთ ინდექსი მომხმარებელს
        try {
            logger.info("შეიყვანე ინდექსი (1-99): ");
            int n = scanner.nextInt();

            if (n < 1 || n >= 100) {
                logger.error("ინდექსი უნდა იყოს 1-დან 99-მდე.");
                return;
            }

            int result = fibonacciRecursive(n);
            logger.info("ფიბონაჩის ელემენტი ინდექსზე " + n + ": " + result);

        } catch (Exception e) {
            logger.error("შეიყვანე სწორი რიცხვი");
        } finally {
            logger.info("პროგრამის გაშვება დასრულდა");
            scanner.close();
        }
    }

    // ფიბონაჩის რიცხვების გენერაცია
    public static int[] generateFibonacciSeries(int length) {
        int[] fibonacci = new int[length];
        fibonacci[0] = 0;
        fibonacci[1] = 1;
        for (int i = 2; i < length; i++) {
            fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
        }
        return fibonacci;
    }

    // ელემენტის პოვნა რეკურსიით
    public static int fibonacciRecursive(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
    }
}
