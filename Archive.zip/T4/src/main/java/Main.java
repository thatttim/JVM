import org.apache.log4j.Logger;
import java.util.Scanner;

public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);

    public static void main(String[] args) {
        // თასქი 1.
        int[] fibonacci = new int[100];
        fibonacci[0] = 0;
        fibonacci[1] = 1;

        for (int i = 2; i < 100; i++) {
            fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
        }

        // თასქი 2: გამოგვაქვს რიცხვები
        for (int number : fibonacci) {
            logger.info("რიცხვი: " + number);
        }

        // თასქი 3: შევაყვანინოთ რიცხვი და რეკურსიით გამოვუტანოთ n-ური წევრი.
        Scanner scanner = new Scanner(System.in);
        logger.info("შეყვანე ნატურალური რიცხვი: ");
        int n = scanner.nextInt();

        if (n < 0 || n >= 100) {
            logger.error("შეიყვანე რიცხვი 1-იდან 99-ამდე");
        } else {
            logger.info("ელემენტი ინდექსით " + n + ": " + fibonacciRecursive(n));
        }

        scanner.close();
    }

    // ენური რიცხვის პოვნა რეკურსიით
    public static int fibonacciRecursive(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
    }
}
